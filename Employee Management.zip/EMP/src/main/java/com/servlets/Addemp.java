package com.servlets;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.JMR.Connection;
import com.JMR.Employee;

@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 2,
maxFileSize = 1024 * 1024 * 10,
maxRequestSize = 1024 * 1024 * 50)
public class Addemp extends HttpServlet {
	private static final long serialVersionUID = 1L;
	InputStream inputStream = null;
  
    public Addemp() {
        super();
        
    }

	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
			
		int  emp_id =Integer.parseInt(request.getParameter("emp_id"));
		String emp_name =request.getParameter("emp_name");
		Part filePart = request.getPart("image");
      
            inputStream = filePart.getInputStream();
            
            byte[] data =new byte[inputStream.available()];
            
            inputStream.read(data);
            
           
            
            
        
		
		Employee emp1=new Employee(emp_id,emp_name,data);
		
	Session s=Connection.getFactory().openSession();
	
		
		
		
		Transaction tx=s.beginTransaction();
		s.save(emp1);
		tx.commit();
		s.close();
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		pw.println("<script type=\"text/javascript\">");
		pw.println("alert('Employee Record Added Successfully');");
		pw.println("</script>");
		RequestDispatcher rd=request.getRequestDispatcher("Addemp.jsp");
		rd.include(request, response);
		
		
		
		
		
		}catch(Exception e) {
			e.printStackTrace();
			
		}
		
	
	}

}
