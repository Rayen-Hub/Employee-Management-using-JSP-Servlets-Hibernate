package com.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.transaction.Transaction;

import org.hibernate.Session;

import com.JMR.Connection;
import com.JMR.Employee;


public class DeleteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public DeleteServlet() {
        super();
       
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			
			int empid=Integer.parseInt(request.getParameter("emp_id").trim());
			Session s=Connection.getFactory().openSession();
			org.hibernate.Transaction tx=s.beginTransaction();
			Employee emp =(Employee)s.get(Employee.class, empid);
			s.delete(emp);
			tx.commit();
			
			s.close();
			response.setContentType("text/html");
			PrintWriter pw=response.getWriter();
			pw.println("<script type=\"text/javascript\">");
			pw.println("alert('Employee Record Deleted Successfully');");
			pw.println("</script>");
			RequestDispatcher rd=request.getRequestDispatcher("Showemp.jsp");
			rd.include(request, response);
			
			
		}catch(Exception e){
			
		}
		
	}

	
	
}
