package com.servlets;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.JMR.Connection;
import com.JMR.Employee;


public class UpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	InputStream inputStream = null; 
	Employee emp1;
   
    public UpdateServlet() {
        super();
       
    }

	
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
			
		
			try {
		     int empid=Integer.parseInt(request.getParameter("empid"));
		 	String emp_name=request.getParameter("emp_name");
			//Part filePart = request.getPart("image");
		     
		    // inputStream = filePart.getInputStream();
	            
	           // byte[] data =new byte[inputStream.available()];
	            
	           // inputStream.read(data);
	            
	            Session s=Connection.getFactory().openSession();
	            Transaction tx=s.beginTransaction();
	            
	            
	         emp1 = (Employee)s.get(Employee.class, empid);
	         emp1.setEmp_name(emp_name);
	        // emp1.setEmp_photo(data);
	         tx.commit();
	 		
	 		
	 		s.close();
		     
			}catch(NumberFormatException ex) {
				ex.printStackTrace();
			}
		     
            
        
      
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		pw.println("<script type=\"text/javascript\">");
		pw.println("alert('Employee Record Updated Successfully');");
		pw.println("</script>");
		RequestDispatcher rd=request.getRequestDispatcher("Showemp.jsp");
		rd.include(request, response);
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

}
